document.addEventListener( "DOMContentLoaded", function( e ){
  Butter({
    config: 'test-config.json'
  });
}, false );

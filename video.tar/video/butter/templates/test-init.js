/* Note: This code is just for testing script functionality on Butter init.
 * Disregard unless you want advanced functionality. */
(function(){
  console.log( "inline test init" );
}());
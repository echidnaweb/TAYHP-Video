function spaces() {
  fixIt();
}
var func = function() {
    fixThisToo();
  };
callMe( arg, arg(), [ "a", "b" ], arg([ a ], moreFunc( with, some, args, [ "a" ] ) ) );

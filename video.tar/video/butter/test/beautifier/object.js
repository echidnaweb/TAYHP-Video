{one:1,two:2}
obj = {    spaces: "alot"        };
func({spaceMe:"please"});
func(      {
              what      : "now",    "1": a,
  b:      "beeeee"}
);

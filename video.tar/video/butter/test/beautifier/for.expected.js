for ( var i = 0; j < 10; j++) {
  unCrunch();
}
for ( i = 0; i < 1000; i++) {}

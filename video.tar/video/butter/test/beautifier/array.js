["a","soclose","gimmie some space"]
inAFunction(      "ASD", [   "yeap"    ]   , "ASDASD'ASDASD'ASDASD"  )    ;
[       "fixmeplease",      prettyPlease         ];
[   callingFuncs()     ,   yeap( with, some, argssssss      )];

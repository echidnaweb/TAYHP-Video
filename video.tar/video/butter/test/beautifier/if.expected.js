if ( someFunc() ) {
  doStuff();
}
if ( this ) {
  doThis();
} else {
  doThat();
}
if ( lotsOfSpace ) {
  getRidOfIt();
}

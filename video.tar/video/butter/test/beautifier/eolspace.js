var a = 0;                     

if ( this ) {     
  doSomething();       
}          

// single line comment

if ( this ) {
  that();
}

/* multi
 * line
 * comment
 */
if ( multi() ) {
  doMulti();
}

function nester() {
  // nested single line
  var single = 0;

  /* nested
   * double
   * line
   * comment
   */
  isFine = true;
}

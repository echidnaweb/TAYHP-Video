while ( something ) {
  betterKeepDoingIt();
}
while ( spaces ) {
  getRidOfEm();
}

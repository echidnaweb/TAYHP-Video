if( !window.__testScript ){
  window.__testScript = [];
}
window.__testScript.push( true );
